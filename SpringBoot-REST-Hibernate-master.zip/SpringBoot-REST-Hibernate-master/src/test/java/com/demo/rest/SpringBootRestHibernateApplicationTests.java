package com.demo.rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRestHibernateApplicationTests {

	@Test
	void contextLoads() {
	}

}
